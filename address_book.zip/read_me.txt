#############################T E L E F O N B U C H#####################################
This phone book was written in Python. The operation is intuitive (add, edit, delete, save). If an entry has been added with Add, it still needs to be saved. To do this, click Save. A dialog will open and confirm the save.
Platform: Windows
Language: German
Database: sqlite
When you open the program, another window opens with a black background, which must be left open during use. When you create an entry for the first time, a database is created, which you should keep in the same folder. 
If you like the program, I would appreciate a donation to my PayPal address martinaledermann@gmail.com Thank you very much!
Enjoy the program!
ml-scripts.de


